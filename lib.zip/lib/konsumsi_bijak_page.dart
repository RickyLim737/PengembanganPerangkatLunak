import 'package:flutter/material.dart';
import 'pilih_makanan_page.dart';  // Import PilihMakananPage

class KonsumsiBijakPage extends StatefulWidget {
  @override
  _KonsumsiBijakPageState createState() => _KonsumsiBijakPageState();
}

class _KonsumsiBijakPageState extends State<KonsumsiBijakPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Konsumsi Bijak"),
        backgroundColor: Colors.green.shade700,
      ),
      backgroundColor: Colors.green.shade50,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Pilih kategori makanan yang bijak!",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.green.shade800),
            ),
            SizedBox(height: 20),
            Text("Text dimasukkan disini", style:TextStyle(fontSize : 24, fontWeight: FontWeight.bold, color: Colors.black)),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  // Navigasi ke halaman PilihMakananPage
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PilihMakananPage(),  // Pindah ke halaman PilihMakananPage
                    ),
                  );
                },
                child: Text('Pilih Makanan Bijak'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade700,
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

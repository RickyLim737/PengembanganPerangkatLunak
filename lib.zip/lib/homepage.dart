import 'package:flutter/material.dart';
import 'konsumsi_bijak_page.dart'; 
import 'detail_page.dart' ;

class HomePage extends StatelessWidget {
  final List<Map<String, String>> features = [
    {
      'title': 'Konsumsi Bijak',
      'desc': 'Belajar memilih barang yang ramah lingkungan dan tidak berlebihan.',
      'imageUrl': 'https://cdn.pixabay.com/photo/2017/01/20/00/05/good-luck-1993688_1280.jpg', // contoh URL
    },
    {
      'title': 'Kurangi Sampah',
      'desc': 'Kenali pentingnya mengurangi limbah dengan tindakan kecil sehari-hari.',
      'imageUrl': 'https://images.unsplash.com/photo-1528323273322-d81458248d40',
    },
    {
      'title': 'Daur Ulang Kreatif',
      'desc': 'Ubah barang bekas menjadi sesuatu yang bermanfaat dan menarik.',
      'imageUrl': 'https://cdn.pixabay.com/photo/2018/04/08/19/55/bottles-3302316_1280.jpg',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        title: Text("Konsumsi & Produksi Berkelanjutan"),
        backgroundColor: Colors.green.shade700,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Selamat datang!",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.green.shade800,
              ),
            ),
            SizedBox(height: 10),
            Text(
              "Mari mulai perjalanan kita menuju gaya hidup yang lebih bijak dan ramah lingkungan. Di sini kamu akan menemukan berbagai tips dan aksi nyata yang bisa kamu lakukan mulai hari ini.",
              style: TextStyle(fontSize: 16, color: Colors.green.shade700),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: features.length,
                itemBuilder: (context, index) {
                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    elevation: 3,
                    margin: EdgeInsets.symmetric(vertical: 10),
                    child: ListTile(
                      leading: Icon(Icons.eco, color: Colors.green.shade700),
                      title: Text(
                        features[index]['title']!,
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(features[index]['desc']!),
                      trailing: Icon(Icons.arrow_forward_ios),
                      onTap: () {
                        // Jika fitur yang dipilih adalah Konsumsi Bijak, pindah ke halaman KonsumsiBijakPage
                        if (features[index]['title'] == 'Konsumsi Bijak') {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => KonsumsiBijakPage(), // Pindah ke halaman KonsumsiBijakPage
                            ),
                          );
                        }
                       if (features[index]['title'] == 'Kurangi Sampah') {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => DetailPage(
                                title: features[index]['title']!,
                                description: features[index]['desc']!,
                                imageUrl: features[index]['imageUrl']!, // tambahkan ini
                              ),
                            ),
                          );
                       }
                       if (features[index]['title'] == 'Daur Ulang Kreatif') {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => DetailPage(
                                title: features[index]['title']!,
                                description: features[index]['desc']!,
                                imageUrl: features[index]['imageUrl']!, // tambahkan ini
                              ),
                            ),
                          );
                       }
                      }
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
